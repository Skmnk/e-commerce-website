import React from "react";
import Products from "./Products";

const Home = () => {
  return (
    <div className="hero">
      <div className="card bg-dark text-white border-0">
        <img
          src="/assets/b3.webp"
          className="card-img"
          alt="Background"
          height="550px"
        />
        <div className="card-img-overlay d-flex flex-column justify-content-center">
          <div className="container">
            <h5 className="card-title display-3 fw-bold mb-0 text-danger">
              Live your life in color
            </h5>
            <p className="card-text lead fs-2 text-dark">30% DISCOUNT</p>
            <p className="card-text lead fs-2 fw-italic text-dark">
              <h3>Check out the collections</h3>
            </p>
          </div>
        </div>
      </div>
      <Products />
    </div>
  );
};

export default Home;
